class HomesController < ApplicationController
  def top
  end

  def index
  end

  def show
  end

  def new
  end

  def edit
  end
end
